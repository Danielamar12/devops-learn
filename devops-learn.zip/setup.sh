#!/bin/bash

# 1. 
ssh-keygen -t ed25519 -C "danielknight536@gmail.com" -f ~/.ssh/id_ed25519 -N ""

# 2. 
echo "----- ADD THIS KEY TO GITHUB -> Settings -> SSH and GPG keys -----"
cat ~/.ssh/id_ed25519.pub
echo "------------------------------------------------------------------"
read -p "Press Enter after adding the SSH key to GitHub..."

# 3. 
cd ~
mkdir -p devops
cd devops
git clone git@github.com:danielknight536/devops-learn.git
cd devops-learn

# 4. 
echo -e '#!/bin/bash\necho start' > may15.sh
chmod +x may15.sh
git add may15.sh
git commit -m "add file"
git push

# 5. 
cp /path/to/may11_solution.txt .
git add may11_solution.txt
git commit -m "add May 11 homework solution"
git push

# 6. 
echo "Done"
