#!/bin/bash
echo start
