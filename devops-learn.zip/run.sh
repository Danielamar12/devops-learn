#!/bin/bash

# 1

# 2

# 3

# 4

# 5
country="israel"
num1=0

# 6
# 7

# 8
func_input() {
    local name="$1"
    echo "hello $name , please write a country"
    read country_input
    echo "$country_input"
}

# 9
country_result=$(func_input "daniel")
country="${country_result^^}"

# 10
num1=$(cat data.txt | wc -l)

# 11
echo "country: $country"
echo "num1: $num1"

# 12
if [ "$num1" -gt 3 ]; then
    echo "yes"
else
    echo "no"
fi
